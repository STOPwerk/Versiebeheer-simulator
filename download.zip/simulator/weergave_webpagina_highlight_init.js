window.addEventListener('load', function () {
    hljs.highlightAll();
});
