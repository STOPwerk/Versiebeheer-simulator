# Versiebeheer.Simulator

Deze map bevat de code voor de simulator.

Voor het uitvoeren van de applicatie: zie de [algemene documentatie](../docs/index.md).

Voor een beschrijving van de implementatie van de applicatie: zie de [code documentatie](documentatie/index.md).
