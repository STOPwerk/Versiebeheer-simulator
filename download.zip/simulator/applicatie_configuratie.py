#======================================================================
#
# Configuratie van de applicatie
#
#======================================================================

Applicatie_versie = "versie d.d. 2022-11-06 18:32:14"

STOP_Documentatie_Url = "https://koop.gitlab.io/STOP/voorinzage/standaard-preview-b/"
STOP_Repository_Url = "https://gitlab.com/koop/STOP/voorinzage/standaard-preview-b/-/tree/master/"
